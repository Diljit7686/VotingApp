package com.example.macbookair.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

public class ThirdCandidateActivity extends AppCompatActivity {
Button c3 , c4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_candidate);


        c3 = findViewById(R.id.c3);
        c4 = findViewById(R.id.c4);


        c3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c3 =new Intent(ThirdCandidateActivity.this, MainActivity.class);
                startActivity(c3);
            }
        });

        c4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c4 =new Intent(ThirdCandidateActivity.this, VotingPageActivity.class);
                startActivity(c4);
            }
        });

}}
