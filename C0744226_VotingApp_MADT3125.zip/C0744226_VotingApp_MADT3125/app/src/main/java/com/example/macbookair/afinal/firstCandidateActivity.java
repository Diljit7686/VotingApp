package com.example.macbookair.afinal;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class firstCandidateActivity extends AppCompatActivity {


    Button btn1,btn2;
    TextView votes;
    int newvote;
   int counter;
   votingDatabaseAdapter votingDatabaseAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_candidate);

        votingDatabaseAdapter = new votingDatabaseAdapter(this);
        votingDatabaseAdapter = votingDatabaseAdapter.open();



        votes = findViewById(R.id.t2);


        btn1 = findViewById(R.id.b3);
        btn2 = findViewById(R.id.b2);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                      counter = counter + 1;
                      votes.setText(String.valueOf(counter));
                       int convert = 1;
          //            int convert = Integer.parseInt(String.valueOf(votes));
                      votingDatabaseAdapter.insertEntry(convert);

                    //  String countQuery = "SELECT * FROM " + votingDatabaseAdapter;

                   String anyName = votingDatabaseAdapter.getSinlgeEntry(convert);
                 Intent homeIntent = new Intent(firstCandidateActivity.this, MainActivity.class);
                startActivity(homeIntent);


            }


        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent votePage = new Intent(firstCandidateActivity.this, VotingPageActivity.class);
                startActivity(votePage);
            }
        });


    }



}

