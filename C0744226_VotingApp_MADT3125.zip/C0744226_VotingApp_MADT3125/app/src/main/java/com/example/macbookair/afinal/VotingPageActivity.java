package com.example.macbookair.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class VotingPageActivity extends AppCompatActivity {
    RadioGroup chooseVote;
    Button voteButton;
    TextView s1;
    TextView s2;
    TextView s3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voting_page);

        chooseVote = findViewById(R.id.groupID);
        voteButton = findViewById(R.id.voteID);


        s1 = findViewById(R.id.firstResultID);
        s2 = findViewById(R.id.secondResultID);
        s3 = findViewById(R.id.thirdresultID);

        voteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int checkedRadioButtonId = chooseVote.getCheckedRadioButtonId();
                if (checkedRadioButtonId == R.id.radio1ID)
                {
                   /* String newResult = s1.getText().toString().trim();
                    int count1 = Integer.parseInt(newResult);
                    count1++;
                    s1.setText(String.valueOf(count1));

                   */

                    Intent firstIntent = new Intent(VotingPageActivity.this, firstCandidateActivity.class);
                    startActivity(firstIntent);
                }
                else if(checkedRadioButtonId == R.id.radio2ID)
                {

                    //
                    Intent secondIntent = new Intent(VotingPageActivity.this, SecondCandidateActivity.class);
                    startActivity(secondIntent);

                }
                else if(checkedRadioButtonId == R.id.radio3ID)
                {
                    // tisri condition
                    Intent thirdIntent = new Intent(VotingPageActivity.this, ThirdCandidateActivity.class);
                    startActivity(thirdIntent);
                }
            }
        });

    }
}
