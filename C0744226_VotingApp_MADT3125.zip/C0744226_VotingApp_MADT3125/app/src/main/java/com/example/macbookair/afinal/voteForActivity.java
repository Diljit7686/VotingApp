package com.example.macbookair.afinal;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class voteForActivity extends AppCompatActivity {

    Button b1;
    Button b2;

    TextView firstCand;
    TextView secondCand;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        secondCand = findViewById(R.id.text1);
        firstCand = findViewById(R.id.text2);


        b2 = findViewById(R.id.btn1);
        b1 = findViewById(R.id.btn2);
    }

    public void onJagClicked(View v){
        String cokeCount = secondCand.getText().toString().trim();
        int count = Integer.parseInt(cokeCount);
        count++;
        secondCand.setText(String.valueOf(count));
    }

    public void onTruClicked(View v){
        String pepsiCount = firstCand.getText().toString().trim();
        int count = Integer.parseInt(pepsiCount);
        count++;
        firstCand.setText(String.valueOf(count));
    }

}

