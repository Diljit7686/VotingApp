package com.example.macbookair.afinal;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

public class SecondCandidateActivity extends AppCompatActivity {

    Button c1,c2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_candidate);

    c1 = findViewById(R.id.c1);
    c2 = findViewById(R.id.c2);


    c1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent c1 = new Intent(SecondCandidateActivity.this, MainActivity.class);
            startActivity(c1);
        }
    });


    c2.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent c2 = new Intent(SecondCandidateActivity.this, VotingPageActivity.class);
            startActivity(c2);

        }
    });

    }

}
