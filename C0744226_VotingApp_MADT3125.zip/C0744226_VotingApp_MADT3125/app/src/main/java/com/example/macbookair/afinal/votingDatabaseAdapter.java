package com.example.macbookair.afinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.widget.TextView;


public class votingDatabaseAdapter {
    static final String DATABASE_NAME = "vote.db";
    static final int DATABASE_VERSION = 2;
    public static final int NAME_COLUMN = 1;
    // TODO: Create public field for each column in your table.
    // SQL Statement to create a new database.
    static final String DATABASE_CREATE = "CREATE TABLE "+"VOTE"+
            "( " +"ID"+" INTEGER PRIMARY KEY AUTOINCREMENT,"+ "VOTES INTEGER); ";


    // Variable to hold the database instance
    public SQLiteDatabase votedb;
    // Context of the application using the database.
    private final Context context;
    // Database open/upgrade helper
    private DataBaseHelper dbHelper;
    private int votes;

    public votingDatabaseAdapter(Context _context) {
        context = _context;
        dbHelper = new DataBaseHelper(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public votingDatabaseAdapter open() throws SQLException {
        votedb = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        votedb.close();
    }

    public SQLiteDatabase getDatabaseInstance() {
        return votedb;
    }

    public void insertEntry(int votes) {
        ContentValues newValues = new ContentValues();
        // Assign values for each row.
        newValues.put("VOTES", votes);


        // Insert the row into your table
        votedb.insert("VOTE", null, newValues);
        //Toast.makeText(context, "Reminder Is Successfully Saved", Toast.LENGTH_LONG).show();
    }

    /*public int deleteEntry(int votes) {
        //String id=String.valueOf(ID);
        String where = "VOTE=?";
        int numberOFEntriesDeleted = votedb.delete("VOTE", where, new String[]{String.valueOf(votes)});
        // Toast.makeText(context, "Number fo Entry Deleted Successfully : "+numberOFEntriesDeleted, Toast.LENGTH_LONG).show();
        return numberOFEntriesDeleted;
    }*/

    public String getSinlgeEntry(int votes) {
        Cursor cursor = votedb.query("VOTE", null, " votes=?", new String[]{String.valueOf(votes)}, null, null, null);
        if (cursor.getCount() < 1) // UserName Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }


    /*    public void updateEntry( int votes)
        {
            // Define the updated row content.
            ContentValues updatedValues = new ContentValues();
            // Assign values for each row.
            updatedValues.put("VOTES", votes);


            String where = "VOTES = ?";
            votedb.update("vote", updatedValues, where, new String[]{String.valueOf(votes)});
        }
        */
        return String.valueOf(votes);
    }
}

